#ifndef EFFECT_INCLUDE
#define EFFECT_INCLUDE


#include "effect.hpp"
#include "EffectDamage.hpp"
#include "EffectDefensive.hpp"
#include "EffectHealth.hpp"
#include "EffectHealthRegen.hpp"
#include "EffectManaRegen.hpp"
#include "EffectPoison.hpp"
#include "EffectTurn.hpp"
#include "EffectTurnBased.hpp"


#endif